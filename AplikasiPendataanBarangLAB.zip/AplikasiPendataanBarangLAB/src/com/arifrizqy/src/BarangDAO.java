/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.arifrizqy.src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author arifrizqy
 */
public class BarangDAO {
    private final String URL = "jdbc:mysql://localhost:3306/db_prak_pemvis";
    private final String USER = "arifrizqy"; // default user mysql= "root"
    private final String PASS = "@Arriz2401"; // default password password= ""
    
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
    
    public List<Barang> getAllBarang() throws SQLException {
        List<Barang> list_barang = new ArrayList();
        
        String sql = "select * from tb_barang_lab";
        
        try (
                Connection conn = getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
        ) {
            while(rs.next()) {
                Barang barang = new Barang(
                        rs.getInt("id"),
                        rs.getString("nama_barang"),
                        rs.getString("kategori"),
                        rs.getString("kondisi"),
                        rs.getInt("jumlah")
                );
                
                list_barang.add(barang);
            }
        }
        
        return list_barang;
    }

    public void insertBarang(Barang p_brg) throws SQLException {
        String sql = "insert into tb_barang_lab (nama_barang, kategori, kondisi, jumlah) values (?, ?, ?, ?)";
        
        try (
                Connection conn = getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
        ) {
            stmt.setString(1, p_brg.getNama_barang());
            stmt.setString(2, p_brg.getKategori());
            stmt.setString(3, p_brg.getKondisi());
            stmt.setInt(4, p_brg.getJmlh());
            
            stmt.executeUpdate();
        }
        
    }
}
