/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.arifrizqy.src;

/**
 *
 * @author arifrizqy
 */
public class Barang {
    private int id, jmlh;
    private String nama_barang, kategori, kondisi;
    
    public Barang(
            int p_id,
            String p_nama_barang,
            String p_kategori,
            String p_kondisi,
            int p_jmlh
    ) {
        this.id = p_id;
        this.nama_barang = p_nama_barang;
        this.kategori = p_kategori;
        this.kondisi = p_kondisi;
        this.jmlh = p_jmlh;
    }

    public void setId(int p_id) {
        this.id = p_id;
    }

    public int getId() {
        return id;
    }

    public void setNama_barang(String p_nama_barang) {
        this.nama_barang = p_nama_barang;
    }

    public String getNama_barang() {
        return nama_barang;
    }

    public void setKategori(String p_kategori) {
        this.kategori = p_kategori;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKondisi(String p_kondisi) {
        this.kondisi = p_kondisi;
    }

    public String getKondisi() {
        return kondisi;
    }

    public void setJmlh(int p_jmlh) {
        this.jmlh = p_jmlh;
    }

    public int getJmlh() {
        return jmlh;
    }
    
    
}
